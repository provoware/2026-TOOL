#!/usr/bin/env python3
import json
from pathlib import Path

m = json.loads(Path("projekt-manifest.json").read_text(encoding="utf-8")); errors = []
if m.get("schema_version") != 1: errors.append("Manifest-schema_version muss 1 sein")
app = m.get("app", {})
if app.get("version") != "0.2.2" or app.get("status") != "release-0.2.2": errors.append("App muss als release-0.2.2 geführt werden")
iteration = m.get("iteration", {})
if iteration.get("number") != 2 or iteration.get("stage") != "2.2" or iteration.get("release") != "0.2.2": errors.append("Iterations-/Releasevertrag muss 2.2 / 0.2.2 sein")
if not iteration.get("qualified_from_head"): errors.append("qualifizierter Kandidaten-Head fehlt")
ui = m.get("ui", {})
if ui.get("areas") != list("ABCDEFGHIJKLMN") or len(ui.get("themes", [])) != 5: errors.append("A-N-/Theme-Vertrag verletzt")
if ui.get("zoom_percent") != {"min":100,"max":200,"step":5}: errors.append("Zoomvertrag muss 100–200 % in 5er Schritten sein")
if set(ui.get("zoom_shortcuts", [])) != {"Ctrl++","Ctrl+-","Ctrl+0","Ctrl+Mausrad"}: errors.append("Zoom-Tastaturvertrag unvollständig")
for flag in ("global_process_feedback","session_warning_error_counters","skip_link","color_only_status_forbidden"):
    if ui.get(flag) is not True: errors.append(f"UI-Vertrag fehlt: {flag}")
quality = m.get("quality", {})
if quality.get("manual_user_acceptance_required") is not False or quality.get("crash_recovery_tests") is not True: errors.append("Qualitätsvertrag Nutzer/Crash verletzt")
if quality.get("self_repair_guarded") is not True or quality.get("risk_model") != "R0-R4": errors.append("Self-Repair-/Risikovertrag verletzt")
if quality.get("agent_contract_validation") != "scripts/validate_agents.py" or quality.get("ux_contract_test") != "tests/test_ux_contract.py": errors.append("Qualitätsprüfer fehlen")
if not quality.get("candidate_release_gate_run") or not quality.get("candidate_subagent_gate_run"): errors.append("Kandidaten-Gate-Evidenz fehlt")
backup = m.get("backup", {})
if backup.get("keep_previous") != 2 or backup.get("database_verified_keep") != 2: errors.append("Backup-Retention muss jeweils 2 sein")
if backup.get("strategy") != "rotating-github-ref-api" or backup.get("ref_update_verified") is not True: errors.append("Backup-Ref-Rotation muss API-basiert und nachvalidiert sein")
if backup.get("workflow_contract_test") != "tests/test_backup_workflow.py": errors.append("Backup-Workflowvertragstest fehlt")
data = m.get("data", {})
if data.get("engine") != "sqlite3" or data.get("schema_version") != 1 or data.get("journal_mode") != "WAL": errors.append("SQLite-Datenvertrag verletzt")
if data.get("calendar_source") != "todos" or data.get("archive_strategy") != "logical-reversible" or data.get("backup_keep") != 2: errors.append("Daten-/Archivvertrag verletzt")
if set(m.get("agents", {})) != {"analysis","risk","root_cause","planning","regression","compliance","release"}: errors.append("Manifest muss exakt sieben Prüfrollen enthalten")
self_repair = m.get("self_repair", {}); allowed = self_repair.get("automatic_scope", []); forbidden = self_repair.get("forbidden_scope", [])
if not isinstance(allowed, list) or len(allowed) < 4 or not isinstance(forbidden, list) or len(forbidden) < 6: errors.append("Self-Repair Allow-/Denylist unvollständig")
if "delete-user-data" not in forbidden or "restore-unverified-backup" not in forbidden: errors.append("kritische Self-Repair-Verbote fehlen")
error_handling = m.get("error_handling", {})
if error_handling.get("stable_api_codes") is not True or error_handling.get("unknown_internal_details_exposed") is not False: errors.append("Fehlerbehandlungsvertrag verletzt")
if errors:
    for error in errors: print("FEHLER:", error)
    raise SystemExit(1)
print("OK   Manifest konsistent – v0.2.2 inklusive verifizierter Backup-Ref-Rotation")
